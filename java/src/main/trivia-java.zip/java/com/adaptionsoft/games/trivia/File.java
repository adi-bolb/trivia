package com.adaptionsoft.games.trivia;

/**
 * Created by adi on 12/4/14.
 */
public interface File {
    void write(String text);
    void createFile(String fileName);
}
