package com.adaptionsoft.games.uglytrivia;

/**
 * Created by adi on 12/4/14.
 */
public class GameResultConsoleWriterImpl implements GameResultWriter {
    public void writeLine(String playerWinMessage) {
        System.out.println(playerWinMessage);
    }
}
