package com.adaptionsoft.games.uglytrivia;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Created by adi on 12/4/14.
 */
public class GameResultFileWriterImpl implements GameResultWriter {
    @Override
    public void writeLine(String message) {
        throw new NotImplementedException();
    }
}
