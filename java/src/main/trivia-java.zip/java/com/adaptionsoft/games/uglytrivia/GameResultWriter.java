package com.adaptionsoft.games.uglytrivia;

/**
 * Created by adi on 12/4/14.
 */
public interface GameResultWriter {
    void writeLine(String message);
}
