package com.adaptionsoft.games.uglytrivia;

/**
 * Created by adi on 12/5/14.
 */
public interface QuestionWriterForMockist {
    void ask(String message);
}
